import ServicesSection from "@/components/dashboard/services/ServicesSection"

const Services = () => {

  return (
    <div className="min-h-full flex md:items-center justify-center">
      <ServicesSection />
    </div>
  )
}

export default Services;