import MobileAppLinks from "@/components/external-pages/homepage/MobileAppLinks"

const PrivacyPolicy = () => {
  return (
    <>
        <section className="bg-[#F9FAFB]">
            <div className="py-10 md:py-24 text-center max-w-[960px] px-5 md:px-20 mx-auto">
                <h1 className="text-[var(--aqua)] text-3xl md:text-5xl font-medium md:font-bold mb-6">Your privacy is our priority</h1>
                <p className="text-[var(--ink)] text-xl">Your privacy is important to us at PayMint. We respect your privacy regarding any information we may collect from you and promise to keep them safe.</p>
            </div>
        </section>
        <section className="bg-white py-16 md:py-24">
            <div className="max-w-[720px] mx-auto px-7 md:px-0">
                <div className="mb-12">
                    <h2 className="text-[var(--aqua)] font-medium md:font-bold text-3xl mb-6">What information do we collect?</h2>
                    <div className="flex flex-col gap-6">
                        <p className="text-[#667085] text-lg">Dolor enim eu tortor urna sed duis nulla. Aliquam vestibulum, nulla odio nisl vitae. In aliquet pellentesque aenean hac vestibulum turpis mi bibendum diam. Tempor integer aliquam in vitae malesuada fringilla.</p>
                        <p className="text-[#667085] text-lg">Elit nisi in eleifend sed nisi. Pulvinar at orci, proin imperdiet commodo consectetur convallis risus. Sed condimentum enim dignissim adipiscing faucibus consequat, urna. Viverra purus et erat auctor aliquam. Risus, volutpat vulputate posuere purus sit congue convallis aliquet. Arcu id augue ut feugiat donec porttitor neque. Mauris, neque ultricies eu vestibulum, bibendum quam lorem id. Dolor lacus, eget nunc lectus in tellus, pharetra, porttitor.</p>
                        <p className="text-[#667085] text-lg">Ipsum sit mattis nulla quam nulla. Gravida id gravida ac enim mauris id. Non pellentesque congue eget consectetur turpis. Sapien, dictum molestie sem tempor. Diam elit, orci, tincidunt aenean tempus. Quis velit eget ut tortor tellus. Sed vel, congue felis elit erat nam nibh orci.</p>
                    </div>
                </div>
                <div className="mb-12">
                    <h2 className="text-[var(--aqua)] font-medium md:font-bold text-3xl mb-6">How do we use your information?</h2>
                    <div className="flex flex-col gap-6">
                        <p className="text-[#667085] text-lg">Dolor enim eu tortor urna sed duis nulla. Aliquam vestibulum, nulla odio nisl vitae. In aliquet pellentesque aenean hac vestibulum turpis mi bibendum diam. Tempor integer aliquam in vitae malesuada fringilla.</p>
                        <p className="text-[#667085] text-lg">Elit nisi in eleifend sed nisi. Pulvinar at orci, proin imperdiet commodo consectetur convallis risus. Sed condimentum enim dignissim adipiscing faucibus consequat, urna. Viverra purus et erat auctor aliquam. Risus, volutpat vulputate posuere purus sit congue convallis aliquet. Arcu id augue ut feugiat donec porttitor neque. Mauris, neque ultricies eu vestibulum, bibendum quam lorem id. Dolor lacus, eget nunc lectus in tellus, pharetra, porttitor.</p>
                        <p className="text-[#667085] text-lg">Ipsum sit mattis nulla quam nulla. Gravida id gravida ac enim mauris id. Non pellentesque congue eget consectetur turpis. Sapien, dictum molestie sem tempor. Diam elit, orci, tincidunt aenean tempus. Quis velit eget ut tortor tellus. Sed vel, congue felis elit erat nam nibh orci.</p>
                    </div>
                </div>
                <div className="mb-12">
                    <h2 className="text-[var(--aqua)] font-medium md:font-bold text-3xl md:text-2xl mb-4">Do we use cookies and other tracking technologies?</h2>
                    <p className="text-[#667085] text-lg">Pharetra morbi libero id aliquam elit massa integer tellus. Quis felis aliquam ullamcorper porttitor. Pulvinar ullamcorper sit dictumst ut eget a, elementum eu. Maecenas est morbi mattis id in ac pellentesque ac.</p>
                </div>
                <div className="mb-12">
                    <h2 className="text-[var(--aqua)] font-medium md:font-bold text-3xl md:text-2xl mb-4">How long do we keep your information?</h2>
                    <p className="text-[#667085] text-lg">Pharetra morbi libero id aliquam elit massa integer tellus. Quis felis aliquam ullamcorper porttitor. Pulvinar ullamcorper sit dictumst ut eget a, elementum eu. Maecenas est morbi mattis id in ac pellentesque ac.</p>
                </div>
                <div className="mb-12">
                    <h2 className="text-[var(--aqua)] font-medium md:font-bold text-3xl md:text-2xl mb-4">How do we keep your information safe?</h2>
                    <p className="text-[#667085] text-lg">Pharetra morbi libero id aliquam elit massa integer tellus. Quis felis aliquam ullamcorper porttitor. Pulvinar ullamcorper sit dictumst ut eget a, elementum eu. Maecenas est morbi mattis id in ac pellentesque ac.</p>
                </div>
                <div className="mb-12">
                    <h2 className="text-[var(--aqua)] font-medium md:font-bold text-3xl md:text-2xl mb-4">What are your privacy rights?</h2>
                    <p className="text-[#667085] text-lg">Pharetra morbi libero id aliquam elit massa integer tellus. Quis felis aliquam ullamcorper porttitor. Pulvinar ullamcorper sit dictumst ut eget a, elementum eu. Maecenas est morbi mattis id in ac pellentesque ac.</p>
                </div>
                <div className="">
                    <h2 className="text-[var(--aqua)] font-medium md:font-bold text-3xl md:text-2xl mb-4">How can you contact us about this policy?</h2>
                    <p className="text-[#667085] text-lg mb-6">Pharetra morbi libero id aliquam elit massa integer tellus. Quis felis aliquam ullamcorper porttitor. Pulvinar ullamcorper sit dictumst ut eget a, elementum eu. Maecenas est morbi mattis id in ac pellentesque ac.</p>
                    <p className="text-[#667085] text-lg">1. Lectus id duis vitae porttitor enim gravida morbi.</p>
                    <p className="text-[#667085] text-lg">2. Eu turpis posuere semper feugiat volutpat elit, ultrices suspendisse. Auctor vel in vitae</p>
                    <p className="text-[#667085] text-lg">3. Suspendisse maecenas ac donec scelerisque diam sed est duis purus.</p>
                </div>
            </div>
        </section>
        <MobileAppLinks />
    </>
  )
}

export default PrivacyPolicy