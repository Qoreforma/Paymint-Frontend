import ContactUsForm from "@/components/external-pages/contact-us-page/ContactUsForm"
import MobileAppLinks from "@/components/external-pages/homepage/MobileAppLinks"

const ContactPage = () => {
  return (
    <>
        <ContactUsForm />
        <MobileAppLinks />
    </>
  )
}

export default ContactPage