import AboutPayMint from "@/components/external-pages/aboutpage/AboutPayMint"
import OurMission from "@/components/external-pages/aboutpage/OurMission"
import MobileAppLinks from "@/components/external-pages/homepage/MobileAppLinks"
import Partnerships from "@/components/external-pages/homepage/Partnerships"
import WhyUse from "@/components/external-pages/homepage/WhyUse"

const About = () => {
  return (
    <>
      <AboutPayMint />
      <OurMission />
      <Partnerships />
      <WhyUse className="bg-[#F9FAFB]" />
      <MobileAppLinks />
    </>
  )
}

export default About