import MobileAppLinks from "@/components/external-pages/homepage/MobileAppLinks"

const TermsPage = () => {
  return (
    <>
        <section className="bg-white py-16 md:py-24">
            <div className="max-w-[720px] mx-auto px-7 md:px-0">
                <div className="mb-12">
                    <h2 className="text-[var(--aqua)] font-medium md:font-bold text-3xl mb-6">Terms & Conditions - GENERAL</h2>
                    <div className="flex flex-col gap-6">
                        <p className="text-[#667085] text-lg">Dolor enim eu tortor urna sed duis nulla. Aliquam vestibulum, nulla odio nisl vitae. In aliquet pellentesque aenean hac vestibulum turpis mi bibendum diam. Tempor integer aliquam in vitae malesuada fringilla.</p>
                        <p className="text-[#667085] text-lg">Elit nisi in eleifend sed nisi. Pulvinar at orci, proin imperdiet commodo consectetur convallis risus. Sed condimentum enim dignissim adipiscing faucibus consequat, urna. Viverra purus et erat auctor aliquam. Risus, volutpat vulputate posuere purus sit congue convallis aliquet. Arcu id augue ut feugiat donec porttitor neque. Mauris, neque ultricies eu vestibulum, bibendum quam lorem id. Dolor lacus, eget nunc lectus in tellus, pharetra, porttitor.</p>
                        <p className="text-[#667085] text-lg">Ipsum sit mattis nulla quam nulla. Gravida id gravida ac enim mauris id. Non pellentesque congue eget consectetur turpis. Sapien, dictum molestie sem tempor. Diam elit, orci, tincidunt aenean tempus. Quis velit eget ut tortor tellus. Sed vel, congue felis elit erat nam nibh orci.</p>
                        <p className="text-[#667085] text-lg">Ipsum sit mattis nulla quam nulla. Gravida id gravida ac enim mauris id. Non pellentesque congue eget consectetur turpis. Sapien, dictum molestie sem tempor. Diam elit, orci, tincidunt aenean tempus. Quis velit eget ut tortor tellus. Sed vel, congue felis elit erat nam nibh orci.</p>
                    </div>
                </div>
                <div className="mb-12">
                    <h2 className="text-[var(--aqua)] font-medium md:font-bold text-3xl mb-6">SECTION A</h2>
                    <div className="flex flex-col gap-6">
                        <p className="text-[#667085] text-lg">Dolor enim eu tortor urna sed duis nulla. Aliquam vestibulum, nulla odio nisl vitae. In aliquet pellentesque aenean hac vestibulum turpis mi bibendum diam. Tempor integer aliquam in vitae malesuada fringilla.</p>
                        <p className="text-[#667085] text-lg">Elit nisi in eleifend sed nisi. Pulvinar at orci, proin imperdiet commodo consectetur convallis risus. Sed condimentum enim dignissim adipiscing faucibus consequat, urna. Viverra purus et erat auctor aliquam. Risus, volutpat vulputate posuere purus sit congue convallis aliquet. Arcu id augue ut feugiat donec porttitor neque. Mauris, neque ultricies eu vestibulum, bibendum quam lorem id. Dolor lacus, eget nunc lectus in tellus, pharetra, porttitor.</p>
                    </div>
                </div>
                <div className="mb-12">
                    <h2 className="text-[var(--aqua)] font-medium md:font-bold text-3xl mb-6">SECTION B</h2>
                    <div className="flex flex-col gap-6">
                        <p className="text-[#667085] text-lg">Dolor enim eu tortor urna sed duis nulla. Aliquam vestibulum, nulla odio nisl vitae. In aliquet pellentesque aenean hac vestibulum turpis mi bibendum diam. Tempor integer aliquam in vitae malesuada fringilla.</p>
                        <p className="text-[#667085] text-lg">Elit nisi in eleifend sed nisi. Pulvinar at orci, proin imperdiet commodo consectetur convallis risus. Sed condimentum enim dignissim adipiscing faucibus consequat, urna. Viverra purus et erat auctor aliquam. Risus, volutpat vulputate posuere purus sit congue convallis aliquet. Arcu id augue ut feugiat donec porttitor neque. Mauris, neque ultricies eu vestibulum, bibendum quam lorem id. Dolor lacus, eget nunc lectus in tellus, pharetra, porttitor.</p>
                    </div>
                </div>
                <div className="mb-12">
                    <h2 className="text-[var(--aqua)] font-medium md:font-bold text-3xl mb-6">SECTION C</h2>
                    <div className="flex flex-col gap-6">
                        <p className="text-[#667085] text-lg">Dolor enim eu tortor urna sed duis nulla. Aliquam vestibulum, nulla odio nisl vitae. In aliquet pellentesque aenean hac vestibulum turpis mi bibendum diam. Tempor integer aliquam in vitae malesuada fringilla.</p>
                        <p className="text-[#667085] text-lg">Elit nisi in eleifend sed nisi. Pulvinar at orci, proin imperdiet commodo consectetur convallis risus. Sed condimentum enim dignissim adipiscing faucibus consequat, urna. Viverra purus et erat auctor aliquam. Risus, volutpat vulputate posuere purus sit congue convallis aliquet. Arcu id augue ut feugiat donec porttitor neque. Mauris, neque ultricies eu vestibulum, bibendum quam lorem id. Dolor lacus, eget nunc lectus in tellus, pharetra, porttitor.</p>
                    </div>
                </div>
                <div className="">
                    <h2 className="text-[var(--aqua)] font-medium md:font-bold text-3xl mb-6">SECTION D</h2>
                    <p className="text-[#667085] text-lg mb-6">Pharetra morbi libero id aliquam elit massa integer tellus. Quis felis aliquam ullamcorper porttitor. Pulvinar ullamcorper sit dictumst ut eget a, elementum eu. Maecenas est morbi mattis id in ac pellentesque ac.</p>
                    <p className="text-[#667085] text-lg">1. Lectus id duis vitae porttitor enim gravida morbi.</p>
                    <p className="text-[#667085] text-lg">2. Eu turpis posuere semper feugiat volutpat elit, ultrices suspendisse. Auctor vel in vitae</p>
                    <p className="text-[#667085] text-lg">3. Suspendisse maecenas ac donec scelerisque diam sed est duis purus.</p>
                </div>
                
            </div>
        </section>
        <MobileAppLinks />
    </>
  )
}

export default TermsPage