import FaqCards from '@/components/external-pages/faq/FaqCards'
import Faqs from '@/components/external-pages/faq/Faqs'
import MobileAppLinks from '@/components/external-pages/homepage/MobileAppLinks'

const Faq = () => {
  return (
    <>
        <Faqs />
        <FaqCards />
        <MobileAppLinks />
    </>
  )
}

export default Faq