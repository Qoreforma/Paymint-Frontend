import Features from "@/components/external-pages/homepage/Features"
import Hero from "@/components/external-pages/homepage/Hero"
import { ArrowRight } from "lucide-react"
import { Link } from "react-router-dom"

const CTASection = () => {
  return (
    <section className="bg-[#0A0F1E] py-20 md:py-32 relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/20 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-[#0A0F1E] to-[#0A0F1E]/50 z-0"></div>
        
        <div className="w-[90%] md:w-[80%] mx-auto relative z-10 px-6 sm:px-8 text-center">
            <div className="max-w-[800px] mx-auto bg-gradient-to-br from-white/10 to-white/5 border border-white/10 p-10 md:p-16 rounded-[2.5rem] backdrop-blur-xl shadow-2xl relative overflow-hidden group">
                <div className="absolute inset-0 bg-gradient-to-r from-[#00E5FF]/20 to-[#583EE6]/20 opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
                <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 relative z-10 tracking-tight">Ready to Upgrade Your Experience?</h2>
                <p className="text-gray-400 text-lg mb-10 max-w-[500px] mx-auto relative z-10">Join thousands of users who trust PayMint for their daily digital transactions.</p>
                <div className="flex justify-center relative z-10">
                    <Link to="/auth/signup" className="flex items-center gap-2 bg-white text-[#0A0F1E] px-8 py-4 rounded-full font-semibold hover:scale-105 transition-transform duration-300 shadow-[0_0_20px_rgba(255,255,255,0.2)]">
                        Get Started For Free
                        <ArrowRight className="w-5 h-5" />
                    </Link>
                </div>
            </div>
        </div>
        
        {/* Soft gradient bridge to the white footer */}
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-b from-transparent to-white pointer-events-none z-20"></div>
    </section>
  )
}

const Homepage = () => {
  return (
    <div className="bg-[#0A0F1E]">
      <Hero />
      <Features />
      <CTASection />
    </div>
  )
}

export default Homepage