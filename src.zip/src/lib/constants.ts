import Layers from "../assets/main-pages/Layers.png"
import Sisyphus from "../assets/main-pages/sisyphus.png"
import Circooles from "../assets/main-pages/circooles.png"
import Catalog from "../assets/main-pages/catalog.png"
import Quotient from "../assets/main-pages/quotient.png"

import Bills from "../assets/main-pages/bills.png"
import Referrals from "../assets/main-pages/referrals.png"
import StaticAccount from "../assets/main-pages/static_account.png"
import VirtualCard from "../assets/main-pages/virtual_cards.png"

import Users from "../assets/main-pages/users.svg"
import Chart from "../assets/main-pages/chart.svg"
import Fast from "../assets/main-pages/fast.svg"
import Flag from "../assets/main-pages/flag.svg"
import Heart from "../assets/main-pages/heart.svg"
import Smiley from "../assets/main-pages/smiley.svg"

import MailIcon from "@/assets/main-pages/mail_icon.png"

import Link from "@/assets/dashboard/link.svg"
import Division from "@/assets/dashboard/division.svg"
import Receipt from "@/assets/dashboard/receipt.svg"
import AvatarGroup from "@/assets/dashboard/Avatar Groups.png"

import { GoHome } from "react-icons/go";
import { LuBriefcase } from "react-icons/lu";
import { FaRegFileLines } from "react-icons/fa6";
import { VscGift } from "react-icons/vsc";
import { RiSettings2Line } from "react-icons/ri";
import { LuSend } from "react-icons/lu";
import { LuDownload, LuPlus  } from "react-icons/lu";
import { IoIosAddCircleOutline } from "react-icons/io";

import Virtual from "@/assets/dashboard/virtual.svg";
import Flutterwave from "@/assets/dashboard/flutter.svg";
import OpayIcon from "@/assets/dashboard/opay.svg";

import MtnIcon from "@/assets/dashboard/mtn.svg"
import AirtelIcon from "@/assets/dashboard/airtel.svg"
import nineMobile from "@/assets/dashboard/9mobile.svg"
import glo from "@/assets/dashboard/globacom.svg"

import { LuBell, LuBookOpenText, LuLink, LuMail } from "react-icons/lu";
import { IoPhonePortraitOutline } from "react-icons/io5";

// NAVBAR
export const navlinks = [
    {
        id: 1,
        label: "Home",
        href:"/"
    },
    {
        id: 2,
        label: "About us",
        href:"/about"
    },
    {
        id: 3,
        label: "Contact us",
        href:"/contact"
    },
]

export const footerLinks = [ 
    {
        id: 1,
        label: "Privacy Policy",
        href:"/privacy-policy"
    },
    {
        id: 2,
        label: "FAQs",
        href:"/faqs"
    },
    {
        id: 3,
        label: "Terms & Conditions",
        href:"/terms"
    },
]

// EXTERNAL PAGES
export const partnerships = [
    {
        id: 1,
        image: Layers,
        width: 146
    },
    {
        id: 2,
        image: Sisyphus,
        width: 169
    },
    {
        id: 3,
        image: Circooles,
        width: 183
    },
    {
        id: 4,
        image: Catalog,
        width: 160
    },
    {
        id: 5,
        image: Quotient,
        width: 187
    },
]

export const features = [
    {
        id: 1,
        image: Bills,
        title: "Seamless bill payment.",
        description: "Our mission is to empower our users with the ability to manage their mobile and digital needs effortlessly. We aim to bridge the gap between technology and convenience, providing a platform that’s not only user-friendly but also reliable and secure. With [Your App Name], you're in control, whether you’re at home, at work, or on the go."
    },
    {
        id: 2,
        image: StaticAccount,
        title: "Get static account.",
        description: "Our mission is to empower our users with the ability to manage their mobile and digital needs effortlessly. We aim to bridge the gap between technology and convenience, providing a platform that’s not only user-friendly but also reliable and secure. With [Your App Name], you're in control, whether you’re at home, at work, or on the go."
    },
    {
        id: 3,
        image: Referrals,
        title: "Refer to earn.",
        description: "Our mission is to empower our users with the ability to manage their mobile and digital needs effortlessly. We aim to bridge the gap between technology and convenience, providing a platform that’s not only user-friendly but also reliable and secure. With [Your App Name], you're in control, whether you’re at home, at work, or on the go."
    },
    {
        id: 4,
        image: VirtualCard,
        title: "Virtual card that works.",
        description: "Our mission is to empower our users with the ability to manage their mobile and digital needs effortlessly. We aim to bridge the gap between technology and convenience, providing a platform that’s not only user-friendly but also reliable and secure. With [Your App Name], you're in control, whether you’re at home, at work, or on the go."
    },
]

export const whyUsePayMint = [
    {
        id: 1,
        icon: Users,
        title: "Care about our customers",
        content: "Understand what matters to our users. Give them what they need to do solve their needs."
    },
    {
        id: 2,
        icon: Heart,
        title: "Excellent customer service",
        content: "Our ever available service team are always ready to attend to your needs."
    },
    {
        id: 3,
        icon: Chart,
        title: "Pride in what we do",
        content: "Value quality and integrity in everything we do. At all times. No exceptions."
    },
    {
        id: 4,
        icon: Smiley,
        title: "Happy customer reviews",
        content: "Our good reviews from our happy and satisfied customers will always speak for us!"
    },
    {
        id: 5,
        icon: Flag,
        title: "No red flags",
        content: "Red flags? Shady offers? Hidden charges? We don’t do that here. 100% Plain and secure."
    },
    {
        id: 6,
        icon: Fast,
        title: "Fast and reliable service",
        content: "Our platform is designed to process your  transactions quickly and accurately."
    },
]

export const faqsContent = [
    {
        id: 1,
        question: "Is there a free trial available?",
        answer: "Yes, you can try us for free for 30 days. If you want, we’ll provide you with a free, personalized 30-minute onboarding call to get you up and running as soon as possible."
    },
    {
        id: 2,
        question: "Can I change my plan later?",
        answer: "Yes, you can try us for free for 30 days. If you want, we’ll provide you with a free, personalized 30-minute onboarding call to get you up and running as soon as possible."
    },
    {
        id: 3,
        question: "What is your cancellation policy?",
        answer: "Yes, you can try us for free for 30 days. If you want, we’ll provide you with a free, personalized 30-minute onboarding call to get you up and running as soon as possible."
    },
    {
        id: 4,
        question: "Can other info be added to an invoice?",
        answer: "Yes, you can try us for free for 30 days. If you want, we’ll provide you with a free, personalized 30-minute onboarding call to get you up and running as soon as possible."
    },
    {
        id: 5,
        question: "How does billing work?",
        answer: "Yes, you can try us for free for 30 days. If you want, we’ll provide you with a free, personalized 30-minute onboarding call to get you up and running as soon as possible."
    },
    {
        id: 6,
        question: "How do I change my account email?",
        answer: "Yes, you can try us for free for 30 days. If you want, we’ll provide you with a free, personalized 30-minute onboarding call to get you up and running as soon as possible."
    },
]

export const faqCards = [
    {
        id: 1,
        icon: MailIcon,
        question: "How do I change my account email?",
        answer: "You can change the email address associated with your account by going to untitled.com/account from a laptop or desktop."
    },
    {
        id: 2,
        icon: MailIcon,
        question: "How do I change my account email?",
        answer: "You can change the email address associated with your account by going to untitled.com/account from a laptop or desktop."
    },
    {
        id: 3,
        icon: MailIcon,
        question: "How do I change my account email?",
        answer: "You can change the email address associated with your account by going to untitled.com/account from a laptop or desktop."
    },
    {
        id: 4,
        icon: MailIcon,
        question: "How do I change my account email?",
        answer: "You can change the email address associated with your account by going to untitled.com/account from a laptop or desktop."
    },
    {
        id: 5,
        icon: MailIcon,
        question: "How do I change my account email?",
        answer: "You can change the email address associated with your account by going to untitled.com/account from a laptop or desktop."
    },
    {
        id: 6,
        icon: MailIcon,
        question: "How do I change my account email?",
        answer: "You can change the email address associated with your account by going to untitled.com/account from a laptop or desktop."
    },

]

// DASHBOARD
export const dashboardLinks = [
    {
        id: 1,
        label: "Dashboard",
        link: "/dashboard",
        subCategories: null,
        icon: GoHome,
    },
    {
        id: 2,
        label: "Services",
        link: "/dashboard/services",
        subCategories: [
            {
                id: 1,
                label: "Airtime",
                href: "/dashboard/services/airtime"
            },
            {
                id: 2,
                label: "Data",
                href: "/dashboard/services/data"
            },
            {
                id: 3,
                label: "Electricity",
                href: "/dashboard/services/electricity"
            },
            {
                id: 4,
                label: "Betting",
                href: "/dashboard/services/betting"
            },
            {
                id: 5,
                label: "TV/Cable",
                href: "/dashboard/services/cable"
            },
            {
                id: 6,
                label: "E-PIN",
                href: "/dashboard/services/epin"
            },
            {
                id: 7,
                label: "E-Sim",
                href: "/dashboard/services/esim"
            },
            {
                id: 8,
                label: "Airtime Print",
                href: "/dashboard/services/airtime-print"
            },
            {
                id: 9,
                label: "Data Print",
                href: "/dashboard/services/data-print"
            },
        ],
        icon: LuBriefcase,
    },
    {
        id: 3,
        label: "History",
        link: "/dashboard/history",
        subCategories: null,
        icon: FaRegFileLines,
    },
    {
        id: 4,
        label: "Affiliate",
        link: "/dashboard/affiliate",
        subCategories: null,
        icon: VscGift,
    },
    {
        id: 5,
        label: "Settings",
        link: "/dashboard/settings",
        subCategories: null,
        icon: RiSettings2Line,
    },
]

export const quickActions = [
    {
        id: 1,
        label: "Transfer Funds",
        href: "/dashboard/transfer-funds",
        icon: LuSend
    },
    {
        id: 2,
        label: "Withdraw Funds",
        href: "/dashboard/withdraw-funds",
        icon: LuDownload
    },
    {
        id: 3,
        label: "Add Funds",
        href: "/dashboard/add-funds",
        icon: LuPlus
    },
    {
        id: 4,
        label: "Static Account",
        href: "/dashboard/static-account",
        icon: IoIosAddCircleOutline
    },
]

export const otherServices = [
    {
        id: 1,
        href: "/dashboard/events",
        icon: Link,
        label: "Events Tickets",
        bgColor: "#FEF6E7",
    },
    {
        id: 2,
        href: "/dashboard/hotels",
        icon: Division,
        label: "Hotel Booking",
        bgColor: "#FCDAEE",
    },
    {
        id: 3,
        href: "/dashboard/book-flight",
        icon: Receipt,
        label: "Flight Booking",
        bgColor: "#E7F6EC",
    },
    {
        id: 4,
        href: "/dashboard/affiliate",
        icon: AvatarGroup,
        label: "Invite and earn",
        bgColor: "#E3EFFC",
    },
]

import RocketIcon from "@/assets/dashboard/rocket-mobile.svg";
import BriefCaseIcon from "@/assets/dashboard/briefcase-mobile.svg";
import CardIcon from "@/assets/dashboard/credit-card-mobile.svg";
import HomeIcon from "@/assets/dashboard/home-mobile.svg";
import RadioIcon from "@/assets/dashboard/radio-mobile.svg";

export const otherServicesMobile = [
    {
        id: 1,
        href: "/dashboard/book-flight",
        title: "Book flights",
        subTitle: "Book one way or round flight trips.",
        icon: RocketIcon
    },
    {
        id: 2,
        href: "/dashboard/events",
        title: "Events",
        subTitle: "Pay event bills.",
        icon: BriefCaseIcon
    },
    {
        id: 3,
        href: "/dashboard/virtual-card",
        title: "Virtual cards",
        subTitle: "Create and manage a virtual card.",
        icon: CardIcon
    },
    {
        id: 4,
        href: "/dashboard/hotels",
        title: "Hotel booking",
        subTitle: "Book hotel rooms easily.",
        icon: HomeIcon
    },
    {
        id: 5,
        href: "/dashboard/services/mobile-money",
        title: "Payment",
        subTitle: "Make mobile payments easily.",
        icon: RadioIcon
    },
]

import Rss from "@/assets/dashboard/rss.svg";
import Globe from "@/assets/dashboard/globe.svg"
import Zap from "@/assets/dashboard/zap.svg"
import HardDrive from "@/assets/dashboard/hard-drive.svg"
import Tv from "@/assets/dashboard/tv.svg"
import Key from "@/assets/dashboard/key.svg"

import Rocket from "@/assets/dashboard/rocket.svg"
import Home from "@/assets/dashboard/home.svg"
import Card from "@/assets/dashboard/credit-card.svg"

export const appServices = [
    {
        id: 1,
        label: "Airtime",
        icon: Rss,
        href: "/dashboard/services/airtime"
    },
    {
        id: 2,
        label: "Data",
        icon: Globe,
        href: "/dashboard/services/data"
    },
    {
        id: 3,
        label: "Electricity",
        icon: Zap,
        href: "/dashboard/services/electricity"
    },
    {
        id: 4,
        label: "Betting",
        icon: HardDrive,
        href: "/dashboard/services/betting"
    },
    {
        id: 5,
        label: "TV/Cable",
        icon: Tv,
        href: "/dashboard/services/cable"
    },
    {
        id: 6,
        label: "E-PIN",
        icon: Key,
        href: "/dashboard/services/epin"
    },
    {
        id: 15,
        label: "Airtime Print",
        icon: Rss,
        href: "/dashboard/services/airtime-print"
    },
    {
        id: 16,
        label: "Data Print",
        icon: Globe,
        href: "/dashboard/services/data-print"
    },

    {
        id: 10,
        label: "Flights",
        icon: Rocket,
        href: "/dashboard/book-flight"
    },
    {
        id: 11,
        label: "Hotels",
        icon: Home,
        href: "/dashboard/hotels"
    },
    {
        id: 12,
        label: "Card",
        icon: Card,
        href: "/dashboard/virtual-card"
    },
    {
        id: 13,
        label: "International Airtime",
        icon: Rss,
        href: "/dashboard/services/international-airtime"
    },
    {
        id: 14,
        label: "International Data",
        icon: Globe,
        href: "/dashboard/services/international-data"
    },

]

export const paymentMethods = [
    {
        id: "virtual",
        label: "Virtual Account",
        icon: Virtual,
        bank_name: "Virtual bank",
        account_number: "0021117795",
        account_name: "FABSPAY - ANNA KESHINRO"
    },
    {
        id: "opay",
        label: "Opay",
        icon: OpayIcon,
        bank_name: "Opay Digital Services",
        account_number: "7060809021",
        account_name: "Anna Keshinro-CHECKOUT"
    },
    {
        id: "flutter",
        label: "Flutterwave",
        icon: Flutterwave,
        bank_name: "Flutterwave",
        account_number: "0026577795",
        account_name: "FLUTTER - ANNA KESHINRO"
    },
] as const

export const NetworkProviders = [
    {
        id: 1,
        name: "mtn",
        logo: MtnIcon
    },
    {
        id: 2,
        name: "airtel",
        logo: AirtelIcon
    },
    {
        id: 3,
        name: "9mobile",
        logo: nineMobile
    },
    {
        id: 4,
        name: "globacom",
        logo: glo
    },
]

import Glodropdown from "@/assets/dashboard/glo-dropdown.png"
import Mtndropdown from "@/assets/dashboard/mtn-dropdown.png"
import Airteldropdown from "@/assets/dashboard/airtel-dropdown.png"
import nineMobiledropdown from "@/assets/dashboard/9mobile-dropdown.png"

export const NetworkProvidersDropdown = [
    {
        label: "Glo",
        logo: Glodropdown,
        textColor: "#066006",
        value: "glo"
    },
    {
        label: "MTN",
        logo: Mtndropdown,
        textColor: "#B8AA2C",
        value: "mtn"
    },
    {
        label: "9mobile",
        logo: nineMobiledropdown,
        textColor: "#008000",
        value: "9mobile"
    },
    {
        label: "Airtel",
        logo: Airteldropdown,
        textColor: "#FF0000",
        value: "airtel"
    },
]

export const settingsData = [
    {
        id: 1,
        title: "Account",
        path: "account",
        subTitle: "View and make changes to your account",
        hasVerifiedTag: true,
        icon: LuMail
    },
    {
        id: 2,
        title: "Security",
        path: "security",
        subTitle: "Security options for your account",
        hasVerifiedTag: false,
        icon: LuBell
    },
    {
        id: 3,
        title: "Bank info",
        path: "bank-info",
        subTitle: "Bank accounts connected to your PayMint account",
        hasVerifiedTag: false,
        icon: LuLink
    },
    {
        id: 4,
        title: "Support",
        path: "support",
        subTitle: "Contact our support 24/7 team",
        hasVerifiedTag: false,
        icon: LuBookOpenText
    },
    {
        id: 5,
        title: "FAQs",
        path: "faqs",
        subTitle: "Get answers to some frequently asked questions",
        hasVerifiedTag: false,
        icon: IoPhonePortraitOutline
    },
]