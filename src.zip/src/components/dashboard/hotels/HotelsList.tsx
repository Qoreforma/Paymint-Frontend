import HotelCard from "./HotelCard"

const HotelsList = () => {
  return (
    <div className="flex flex-col gap-5">
        <HotelCard />
        <HotelCard />
        <HotelCard />
        <HotelCard />
        <HotelCard />
        <HotelCard />
    </div>
  )
}

export default HotelsList