import { GoSignOut } from "react-icons/go";

import VerifiedIcon from "@/assets/dashboard/verified_tick.png";
import { useMutation } from "@tanstack/react-query";
import { Logout } from "@/lib/api/authApi";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";
import { AxiosError } from "axios";
import { Link } from "react-router-dom";
import UserAvatar from "@/components/ui/UserAvatar";

const SidebarFooter = () => {
    const {clearAuthData, user} = useAuth()

    const {mutate, isPending: isLoggingOut} = useMutation({
        mutationFn: Logout,
        onSuccess: (data) => {
            clearAuthData();
            console.log({data})
            toast.success("Logged out.")
        },
        onError: (error: AxiosError) => {
            console.log({error})
            const errData = error.response?.data as { message?: string };
            if(errData.message){
                return toast.error(errData.message)
            }
            toast.error("Something went wrong, please try again")
        }
    })
  return (
    <footer className="pt-4 pb-6 mt-auto border-t-[3px] border-dashed border-slate-200 bg-[var(--paper)] mx-2 mb-2 rounded-xl">
        <div className="w-full h-full px-3 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
                
                <div className="relative size-10">
                    <UserAvatar user={user} className="bg-blue-100" />
                    <img src={VerifiedIcon} className="size-3.5 object-cover absolute right-0 bottom-0" />
                </div>

                <Link className="hover:opacity-70 transition" to="/dashboard/settings/account">
                    <div className="flex flex-col h-full justify-center">
                        <h2 className="font-medium text-sm capitalize">{user?.firstname} {user?.lastname}</h2>
                        <small className="text-sm text-[#98A2B3] ">@{user?.username}</small>
                    </div>
                </Link>
            </div>

            {isLoggingOut ? <Loader2 className="animate-spin text-[#727884] size-4" /> : <button onClick={() => mutate()} className="cursor-pointer">
                <GoSignOut className="text-[#727884] hover:text-[var(--aqua)] transition" />
            </button>}
        </div>
    </footer>
  )
}

export default SidebarFooter;