import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useQuery, useMutation } from "@tanstack/react-query";

import BackButton from "@/components/Authentication/BackButton";
import CustomButton from "@/components/CustomButton";
import useAddFundsStore from "@/stores/useAddFundsStore";
import { fetchProviders, fundWallet } from "@/lib/api/dashboard-apis/walletApis";
import { AxiosError } from "axios";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { MdRadioButtonChecked, MdRadioButtonUnchecked } from "react-icons/md";
import { TGeneratedBankAccount, TPaymentProvider, TFundWalletPayload } from "./SelectPaymentMethod";

const MergedFormSchema = z.object({
  amount: z.string().min(2, "please enter a valid amount"),
});

type TFormData = z.infer<typeof MergedFormSchema>

const EnterAmount = () => {
    const {update, paymentMethod, amount} = useAddFundsStore();

    const {
            register,
            formState: {errors},
            handleSubmit
    } = useForm<TFormData>({
        resolver: zodResolver(MergedFormSchema),
        defaultValues: {
            amount: amount || ""
        }
    })

    const {
        data: providers,
        isLoading: isProvidersLoading,
    } = useQuery<TPaymentProvider[], Error>({
        queryKey: ["virtual-accounts-providers"],
        queryFn: fetchProviders,
    })

    const {mutate, isPending} = useMutation<TGeneratedBankAccount, AxiosError, TFundWalletPayload>({
      mutationFn: fundWallet,
      onSuccess: (data) => {
        update({generatedAccount: data})
        update({step: 2}); // Go straight to MakePayment (step 2)
      },
      onError: (error: AxiosError) => {
        const errData = error.response?.data as { message?: string };
          if(errData.message){
              return toast.error(errData.message)
        }
        toast.error("Something went wrong, please try again")
      }
    })

    const onSubmit = (data: TFormData) => {
        if(!paymentMethod) {
            toast.error("Please select a funding method");
            return;
        }
        update({amount: data.amount});
        mutate({provider: paymentMethod.code, amount: data.amount})
    }

  return (
    <section className="w-full max-w-[360px] mx-auto max-md:self-start pb-10">
        <div className="flex items-center mb-10 mt-2 md:hidden fixed top-2 w-full max-w-[360px] mx-auto right-0 left-0 z-10 backdrop-blur-[2px] px-5">
            <BackButton icon href="/dashboard"/>
            <p className="text-[#667085] font-medium text-xl w-full text-center mr-6">Fund account</p>
        </div>

        <div className="max-md:hidden">
            <BackButton className="mb-8" href="/dashboard" />
            <h1 className="text-[var(--aqua)] font-medium text-2xl">Add funds</h1>
            <p className="text-[#717171] mt-2">Enter amount and select a funding method below</p>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="w-full mt-14 md:mt-5">
            <div className="w-full">
                <label className="text-sm text-[#344054] font-medium" htmlFor="amount">Amount to fund</label>
                <div className="w-full h-fit relative mt-1.5">
                    <input {...register("amount")} placeholder="5,000" className="w-full border-[0.5px] border-[#D0D5DD] rounded-lg py-2.5 px-3.5 pl-10 bg-white outline-none focus:border-[var(--aqua)] placeholder:text-sm placeholder:text-[#667085]" type="number" min={1} id="amount" />
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2">₦</span>
                </div>
                {errors.amount && <p className="text-red-500 text-sm mt-1">{errors.amount.message}</p>}
            </div>

            <div className="w-full mt-8 flex flex-col gap-2 md:gap-4">
                <label className="text-sm text-[#344054] font-medium">Select a funding method</label>
                {
                    isProvidersLoading && Array.from({length: 2}).map((_, index) => (
                        <div key={index} className="w-full rounded-[5px] bg-gray-200/70 h-[54px] animate-pulse" />
                    ))
                }
                {
                    !isProvidersLoading && providers && providers.length > 0 && providers.map((prov) => (
                      prov.paymentOptions.includes("bank_transfer") &&
                        <div key={prov.name} onClick={() => update({paymentMethod: prov})} className={cn("w-full rounded-[5px] px-3.5 border bg-white h-[54px] flex items-center gap-2 transition cursor-pointer hover:border-[var(--aqua)]", prov === paymentMethod ? "border-[var(--aqua)]" : "border-slate-200")}>
                            <img className="size-[26px] object-cover" src={prov.logo} alt={prov.name} />
                            <span className="text-sm text-[#31373D]">{prov.name}</span>
                            <span className="ml-auto">
                                {
                                    prov === paymentMethod ? <MdRadioButtonChecked className="size-5 text-[var(--aqua)]" /> : <MdRadioButtonUnchecked className="size-5 text-slate-300" /> 
                                }
                            </span>
                        </div>
                    ))
                }
            </div>

            <CustomButton isLoading={isPending} disabled={isPending || isProvidersLoading} className="mt-10 md:mt-8 w-full">Proceed - <span className="opacity-60">Payment</span></CustomButton>
        </form>
    </section>
  )
}

export default EnterAmount