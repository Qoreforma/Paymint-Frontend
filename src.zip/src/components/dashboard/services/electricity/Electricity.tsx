import { useEffect, useMemo } from "react";

import useIsMobile from "@/hooks/useIsMobile";
import useElectricityBillsStore from "@/stores/useElectricityBillsStore";
import SelectProvider from "./SelectProvider";
import RecipientDetails from "./RecipientDetails";
import ConfirmElectricityPayment from "./ConfirmElectricityPayment";
import Status from "./Status";
import { useQuery } from "@tanstack/react-query";
import { getServicesStatus, ServicesData } from "@/lib/api/dashboard-apis/generics";
import Loader from "@/components/Loader";
import EmptyState from "../../EmptyState";

const Electricity = () => {
    const isMobile = useIsMobile();
    
    const { data: servicesStatus, isLoading } = useQuery<ServicesData, Error>({
        queryKey: ["servicesStatus"],
        queryFn: getServicesStatus,
    });

    const statusMsg = servicesStatus?.electricity.status !== "active" ? servicesStatus?.electricity.message : null;

    const ElectricityBillsSteps = useMemo(() => isMobile 
    ? [
      {
          id: 1,
          component: RecipientDetails
      },
      {
          id: 2,
          component: ConfirmElectricityPayment
      },
      {
          id: 3,
          component: Status
      },
  ] :  [
        {
            id: 1,
            component: SelectProvider
        },
        {
            id: 2,
            component: RecipientDetails
        },
        {
            id: 3,
            component: ConfirmElectricityPayment
        },
        {
            id: 4,
            component: Status
        },
    ], [isMobile])

    const {step, reset} = useElectricityBillsStore();
  
        useEffect(() => {
            reset();
          }, [reset]);

    if (isMobile === null) return null;
    
    const CurrentComponent = ElectricityBillsSteps[step - 1].component;

    if (isLoading) return <Loader className="w-full h-full" />;

    if (statusMsg) return <EmptyState showBackBtn={true} text={statusMsg} />;
    
    return (
        <div className="min-h-full flex md:items-center justify-center">
            <CurrentComponent />
        </div>
      )
}

export default Electricity