import { FormEvent, useState } from "react"

import { formatAmount } from "@/lib/utils";
import CustomButton from "@/components/CustomButton"
import BackButton from "@/components/Authentication/BackButton"
import EnterPin from "@/components/dashboard/EnterPin";
import useIsMobile from "@/hooks/useIsMobile";
import useESimStore from "@/stores/useESimStore";

const ConfirmESimPayment = () => {
  const [paymenTPin, SetPaymenTPin] = useState<string>("");
  const [showPinForm, setShowPinForm] = useState(false);

  const isMobile = useIsMobile();
  const { update, step } = useESimStore();

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
    //  Make API call to make book event
        console.log({ paymenTPin})

    // if successful
        update({step: step+1, isSuccessful: false});
    }

  return (
    <div className="min-h-full flex md:items-center justify-center">
      {
        showPinForm ? 
          <section className="flex flex-col max-md:justify-center max-md:text-center">
                <BackButton icon={isMobile} action={() => setShowPinForm(false)} className="mb-8" />

                <h1 className="text-[var(--aqua)] font-medium text-2xl">Confirm Payment</h1>
                <p className="text-[#717171] mt-2 text-sm md:text-base">Enter your transaction pin to confirm this purchase</p>

                <EnterPin handleSubmit={handleSubmit} value={paymenTPin} onValueChange={SetPaymenTPin} />
          </section> :
          <section className="w-full max-w-[358px] mx-auto flex flex-col max-md:justify-center max-md:text-center">
            <BackButton icon={isMobile} action={() => update({step: step-1})} className="mb-8" />
            <h1 className="text-[var(--aqua)] font-medium text-2xl">Confirm purchase</h1>
            <p className="text-[#717171] md:mt-2">Confirm the details of this purchase</p>

            <p className="text-[#101828] md:text-xl my-5 md:my-8">You are about to purchase ESIM from <span className="font-medium">Nigeria</span> for <span className="font-medium">{formatAmount(1000)}</span>.</p>
            <CustomButton onClick={() => setShowPinForm(true)} className="w-full mx-auto">Proceed - <span className="opacity-60">Confirm Purchase</span></CustomButton>
          </section>
          }
    </div>
  )
}

export default ConfirmESimPayment