import CustomButton from "@/components/CustomButton"
import { DataRecipientDetailFormSchema } from "@/lib/zodSchemas/dashboard.schema"
import { zodResolver } from "@hookform/resolvers/zod"
import { useEffect, useMemo, useState } from "react"
import { Controller, useForm } from "react-hook-form"
import PhoneInput from "react-phone-input-2"
import { z } from "zod"
import { motion } from "framer-motion"
import useServiceFlowStore from "@/stores/useServiceFlowStore"
import { cn, convertToLocalPhoneNumber, formatAmount, detectNigerianNetwork } from "@/lib/utils"
import BackButton from "@/components/Authentication/BackButton"
import { toast } from "sonner"
import { useNavigate } from "react-router-dom"
import { Loader2 } from "lucide-react"
import { useMutation, useQuery } from "@tanstack/react-query"
import { fetchAllDataPlans, fetchDataProviders, verifyPhoneNumber, TDataServiceProvider, IDataPlan } from "@/lib/api/dashboard-apis/servicesApis"
import { phoneNoVerificationResponse, VerifyPhoneNoPayload } from "../airtime/RecipientDetails"
import { AxiosError } from "axios"
import { BsCheck2Circle } from "react-icons/bs"
import { useAuth } from "@/context/AuthContext"

import NetworkProviderPicker from "../shared/NetworkProviderPicker"
import DataPlanPicker from "../shared/DataPlanPicker"

type TFormData = z.infer<typeof DataRecipientDetailFormSchema>

const RecipientDetails = () => {
    const [prodAmount, setProdAmount] = useState<number | undefined>();
    const navigate = useNavigate()
    const [isFocused, setIsFocused] = useState(false);
    
    // validity filter state
    const [selectedValidity, setSelectedValidity] = useState<string>("All");

    const { user } = useAuth();
    const { update, step, providerName, providerId, plan, dataPlans, cashbackRule } = useServiceFlowStore();

    const {
        formState: { errors },
        handleSubmit,
        control,
        watch,
        setValue
    } = useForm<TFormData>({
        resolver: zodResolver(DataRecipientDetailFormSchema),
        defaultValues: {
            phone: user?.phone || "",
        }
    })

    const { mutate, isPending: isVerifying, data: verifiedPhone, error: verifyError } = useMutation<phoneNoVerificationResponse, AxiosError, VerifyPhoneNoPayload>({
        mutationFn: verifyPhoneNumber,
    })

    let verifyErrData: { message?: string } | undefined;
    if (verifyError?.response?.data) {
        verifyErrData = verifyError.response.data as { message?: string };
    }

    const {
        data: providers,
        isLoading,
    } = useQuery<TDataServiceProvider[], Error>({
        queryKey: ["data-providers"],
        queryFn: fetchDataProviders,
    })

    const {
        data: DataPlans,
        isLoading: fetchingPlans,
        error: fetchPlansError,
        isSuccess
    } = useQuery<IDataPlan[], Error, IDataPlan[], [string, string]>({
        queryKey: ['data-plans', providerId as string],
        queryFn: fetchAllDataPlans,
        enabled: !!providerId
    });

    const phoneNo = watch("phone");

    // Auto-detect network when phone number changes
    useEffect(() => {
        if (!phoneNo || !providers) return;
        
        const detectedNetwork = detectNigerianNetwork(phoneNo);
        if (detectedNetwork) {
            // Find the provider that matches the detected network code
            const matchedProvider = providers.find(p => p.code.toLowerCase().includes(detectedNetwork));
            if (matchedProvider && matchedProvider.id !== providerId) {
                update({ providerName: matchedProvider.code, providerId: matchedProvider.id, plan: "" });
            }
        }
    }, [phoneNo, providers, update, providerId]);

    useEffect(() => {
        const delayDebounce = setTimeout(() => {
            if (phoneNo && phoneNo.length >= 10 && providerName) {
                mutate({ phone: convertToLocalPhoneNumber(phoneNo), network: providerName })
            }
        }, 1000);

        return () => clearTimeout(delayDebounce)
    }, [phoneNo, mutate, providerName])

    useEffect(() => {
        if (isSuccess && DataPlans) {
            update({ dataPlans: DataPlans });
        }
    }, [isSuccess, DataPlans, update]);

    const selectedPlan = useMemo(() => {
        return dataPlans?.find((dataPlan) => dataPlan.id === plan) ?? null;
    }, [dataPlans, plan]);

    useEffect(() => {
        setProdAmount(selectedPlan?.amount)
        if (selectedPlan) {

            // Need to set the purchase type based on the selected plan's dataType for the actual buy request
            update({ type: selectedPlan.dataType as "DIRECT" | "SME" });
        }
    }, [selectedPlan, setValue, update])

    // Derive dynamic validities
    const validities = useMemo(() => {
        if (!DataPlans) return ["All"];
        const uniqueValidities = Array.from(new Set(DataPlans.map(p => p.validity).filter(Boolean)));
        return ["All", ...uniqueValidities];
    }, [DataPlans]);

    // Filter plans
    const filteredPlans = useMemo(() => {
        if (!DataPlans) return [];
        if (selectedValidity === "All") return DataPlans;
        return DataPlans.filter(p => p.validity === selectedValidity);
    }, [DataPlans, selectedValidity]);


    const onSubmit = (data: TFormData) => {
        if (!plan) {
            toast.info("Please select a plan!")
            return;
        }
        const localPhone = convertToLocalPhoneNumber(data.phone)
        update({ step: step + 1, phone: localPhone })
    }

    return (
        <section className="w-full max-w-3xl mx-auto px-4 md:px-0">
            <div className="flex items-center mb-10 mt-2 md:hidden fixed top-2 w-full max-w-[360px] mx-auto right-0 left-0 z-10 backdrop-blur-[2px] px-5">
                <BackButton icon action={() => navigate(-1)} />
                <p className="text-[#667085] font-medium text-xl w-full text-center mr-6">Buy Data</p>
            </div>

            <div className="hidden md:block">
                <BackButton className="mb-8" action={() => navigate(-1)} />
                <h1 className="font-medium text-2xl text-[var(--aqua)] mb-2">Recipient details</h1>
                <h2 className=" text-[#717171]">Enter your recipient details and select a data plan</h2>
            </div>

            <form onSubmit={handleSubmit(onSubmit)} className="mt-14 md:mt-5 flex flex-col gap-8 pb-10">
                
                {/* Phone and Network section */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-6">
                    <div className="w-full order-1 md:order-1">
                        <label className="text-[#344054] text-sm font-medium mb-2 block" htmlFor="lastname">Phone number</label>
                        <Controller
                            name="phone"
                            control={control}
                            render={({ field }) => (
                                <PhoneInput
                                    country={'ng'}
                                    value={field.value}
                                    onChange={field.onChange}
                                    placeholder="phone number"
                                    onFocus={() => setIsFocused(true)}
                                    onBlur={() => {
                                        setIsFocused(false)
                                        field.onBlur()
                                    }}
                                    inputProps={{
                                        name: "phone",
                                    }}
                                    buttonStyle={{
                                        borderRadius: "8px 0 0 8px",
                                        border: isFocused ? "1px solid var(--brand-ink)" : "1px solid #D0D5DD",
                                        background: "#FFFFFF",
                                    }}
                                    inputStyle={{
                                        width: "100%",
                                        outline: "0",
                                        background: "#FFFFFF",
                                        height: "48px",
                                        border: isFocused ? "1px solid var(--brand-ink)" : "1px solid #D0D5DD",
                                        boxShadow: "0px 1px 3px rgba(16, 24, 40, 0.04)",
                                        borderRadius: "8px",
                                        color: "#344054",
                                        fontSize: "16px",
                                    }}
                                />
                            )}
                        />
                        {(!isVerifying && verifyErrData) && <p className="text-red-500 text-sm mt-1">{verifyErrData?.message?.replace("-data", "")}</p>}
                        {isVerifying && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { duration: .5 } }} className="flex items-center gap-2 mt-2"><Loader2 className="animate-spin size-4 text-[var(--brand-ink)]" /> <span className="italic text-sm text-slate-500">Verifying phone number</span></motion.div>}
                        {verifiedPhone?.isValid && (
                            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { duration: .5 } }} className="flex mt-2 items-center gap-2">
                                <div className="grid place-items-center size-5 rounded-full bg-[var(--money-in)] text-white"><BsCheck2Circle className="size-3" /> </div>
                                <p className="text-sm font-medium text-[var(--money-in)]">Verified</p>
                            </motion.div>
                        )}
                        {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone.message}</p>}
                    </div>

                    <div className="w-full order-2 md:order-2">
                        <NetworkProviderPicker
                            providers={providers}
                            isLoading={isLoading}
                            selectedProviderCode={providerName}
                            onSelect={(code, id) => update({ providerName: code, providerId: id, plan: "" })}
                        />
                    </div>
                </div>

                {/* Plans section */}
                {providerId && (
                    <div className="w-full bg-white rounded-xl border border-slate-200 p-4 md:p-5 shadow-sm">
                        <div className="flex flex-col md:flex-row md:items-center justify-between mb-4 gap-3">
                            <h3 className="text-sm text-[#344054] font-medium">Select a Data Plan</h3>
                            
                            {/* Validity Filter */}
                            {!fetchingPlans && !fetchPlansError && validities.length > 1 && (
                                <div className="flex flex-wrap items-center gap-2">
                                    {validities.map((validity) => (
                                        <button
                                            key={validity}
                                            type="button"
                                            onClick={() => setSelectedValidity(validity)}
                                            className={cn(
                                                "px-3 py-1.5 text-xs font-medium rounded-full transition-colors",
                                                selectedValidity === validity 
                                                    ? "bg-[var(--brand-ink)] text-white" 
                                                    : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                                            )}
                                        >
                                            {validity}
                                        </button>
                                    ))}
                                </div>
                            )}
                        </div>

                        <DataPlanPicker
                            plans={filteredPlans}
                            isLoading={fetchingPlans}
                            error={fetchPlansError}
                            selectedPlanId={plan}
                            onSelect={(id) => update({ plan: id })}
                        />
                    </div>
                )}

                {/* Bottom confirmation section */}
                {plan && (
                    <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-6 items-end">
                        <div className="w-full">
                            <label className="text-sm text-[#344054] font-medium block mb-2" htmlFor="amount">Amount Payable</label>
                            <div className="w-full h-fit relative">
                                <input
                                    disabled
                                    value={prodAmount ? formatAmount(prodAmount) : ""}
                                    className="w-full border-[0.5px] border-[#D0D5DD] rounded-lg py-3 px-4 bg-slate-50 text-slate-700 outline-none font-mono text-xl font-semibold disabled:opacity-100"
                                    id="amount"
                                />
                            </div>
                            
                            {cashbackRule && (
                                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="w-full mt-3 bg-[var(--money-in)]/10 border border-[var(--money-in)]/20 rounded-lg p-3 flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                        <div className="bg-[var(--money-in)]/20 rounded-full p-1"><BsCheck2Circle className="text-[var(--money-in)] size-4" /></div>
                                        <span className="text-sm font-medium text-[var(--money-in)]">
                                            Earn {cashbackRule?.type === 'percentage'
                                                ? `${cashbackRule?.value}%`
                                                : formatAmount(Number(cashbackRule?.value))} Cashback
                                        </span>
                                    </div>
                                </motion.div>
                            )}
                        </div>

                        <CustomButton
                            disabled={fetchingPlans || isLoading || !plan || !phoneNo}
                            className="w-full !bg-[var(--brand)] hover:!bg-[var(--brand-ink)] !text-white !h-12"
                        >
                            Proceed - <span className="opacity-80 ml-1">Confirm Purchase</span>
                        </CustomButton>
                    </div>
                )}

            </form>
        </section>
    )
}

export default RecipientDetails
