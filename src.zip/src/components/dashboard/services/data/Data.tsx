import { useEffect } from "react";

import RecipientDetails from "./RecipientDetails";
import useServiceFlowStore from "@/stores/useServiceFlowStore";
import ConfirmDataPayment from "./ConfirmDataPayment";
import Status from "./Status";
import { getServicesStatus, getCashbackRules, ServicesData } from "@/lib/api/dashboard-apis/generics";
import { useQuery } from "@tanstack/react-query";
import Loader from "@/components/Loader";
import EmptyState from "../../EmptyState";

const Data = () => {

    const { data: servicesStatus, isLoading } = useQuery<ServicesData, Error>({
        queryKey: ["servicesStatus"],
        queryFn: getServicesStatus,
    });

    const { data: cashbackRules } = useQuery({
        queryKey: ["cashbackRules", servicesStatus?.data?._id],
        queryFn: () => getCashbackRules(servicesStatus?.data?._id as string),
        enabled: !!servicesStatus?.data?._id,
    });

    const statusMsg = servicesStatus?.data.status !== "active" ? servicesStatus?.data.message : null;
  
  const DataPurchaseSteps = [
    { id: 1, component: RecipientDetails },
    { id: 2, component: ConfirmDataPayment },
    { id: 3, component: Status },
  ];

  const {step, reset, update} = useServiceFlowStore();

    useEffect(() => {
        reset();
    }, [reset]);

    useEffect(() => {
        if (cashbackRules && cashbackRules.length > 0) {
            update({ cashbackRule: cashbackRules[0] });
        }
    }, [cashbackRules, update]);

    const CurrentComponent = DataPurchaseSteps[step - 1]?.component || DataPurchaseSteps[0].component;

    if (isLoading) return <Loader className="w-full h-full" />;

    if (statusMsg) return <EmptyState showBackBtn={true} text={statusMsg} />;
  
  return (
    <div className="min-h-full flex md:items-center justify-center">
        <CurrentComponent />
    </div>
  )
}

export default Data;