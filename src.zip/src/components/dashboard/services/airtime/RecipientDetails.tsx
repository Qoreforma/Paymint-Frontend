import CustomButton from "@/components/CustomButton"
import { AirtimeRecipientDetailFormSchema } from "@/lib/zodSchemas/dashboard.schema"
import useServiceFlowStore from "@/stores/useServiceFlowStore"
import { zodResolver } from "@hookform/resolvers/zod"
import { useEffect, useState } from "react"
import { Controller, useForm } from "react-hook-form"
import PhoneInput from "react-phone-input-2"
import { z } from "zod"

import BackButton from "@/components/Authentication/BackButton"
import { useNavigate } from "react-router-dom"
import { Loader2 } from "lucide-react"
import { convertToLocalPhoneNumber, formatAmount, detectNigerianNetwork } from "@/lib/utils"
import { useMutation, useQuery } from "@tanstack/react-query"
import { fetchAirtimeProviders, verifyPhoneNumber, TAirtimeServiceProvider } from "@/lib/api/dashboard-apis/servicesApis"
import { AxiosError } from "axios"
import { BsCheck2Circle } from "react-icons/bs"
import { motion } from "framer-motion"
import { Wallet } from "../../main-page/BalanceCard"
import { getWallet } from "@/lib/api/dashboard-apis/walletApis"
import NetworkProviderPicker from "../shared/NetworkProviderPicker"
import { useAuth } from "@/context/AuthContext"

export type VerifyPhoneNoPayload = { phone: string; network: string };
export type phoneNoVerificationResponse = {
    isValid: boolean;
};

type TFormData = z.infer<typeof AirtimeRecipientDetailFormSchema>

const RecipientDetails = () => {
    const [isFocused, setIsFocused] = useState(false);
    const { user } = useAuth();

    const {
        data: wallet,
        isLoading: fetchingWallet
    } = useQuery<Wallet, Error>({
        queryKey: ["wallet-balance"],
        queryFn: getWallet,
    })

    const navigate = useNavigate()
    const { update, step, provider, cashbackRule } = useServiceFlowStore();

    const {
        register,
        formState: { errors },
        handleSubmit,
        watch,
        control
    } = useForm<TFormData>({
        resolver: zodResolver(AirtimeRecipientDetailFormSchema),
        defaultValues: {
            phone: user?.phone || ""
        }
    })

    const { mutate, isPending: isVerifying, data: verifiedPhone, error: verifyError } = useMutation<phoneNoVerificationResponse, AxiosError, VerifyPhoneNoPayload>({
        mutationFn: verifyPhoneNumber,
    })

    let verifyErrData: { message?: string } | undefined;
    if (verifyError?.response?.data) {
        verifyErrData = verifyError.response.data as { message?: string };
    }

    const {
        data: providers,
        isLoading,
    } = useQuery<TAirtimeServiceProvider[], Error>({
        queryKey: ["airtime-providers"],
        queryFn: fetchAirtimeProviders,
    })

    const phoneNo = watch("phone");

    // Auto-detect network when phone number changes
    useEffect(() => {
        if (!phoneNo || !providers) return;
        
        const detectedNetwork = detectNigerianNetwork(phoneNo);
        if (detectedNetwork) {
            // Find the provider that matches the detected network code
            const matchedProvider = providers.find(p => p.code.toLowerCase().includes(detectedNetwork));
            if (matchedProvider && matchedProvider.code !== provider) {
                update({ provider: matchedProvider.code });
            }
        }
    }, [phoneNo, providers, update, provider]);

    useEffect(() => {
        const delayDebounce = setTimeout(() => {
            if (phoneNo && phoneNo.length >= 10 && provider) {
                mutate({ network: provider, phone: convertToLocalPhoneNumber(phoneNo) })
            }
        }, 1000);

        return () => clearTimeout(delayDebounce)
    }, [phoneNo, mutate, provider])

    const onSubmit = (data: TFormData) => {
        const localPhone = convertToLocalPhoneNumber(data.phone)
        update({ step: step + 1, phone: localPhone, amount: data.amount })
    }

    return (
        <section className="w-full max-w-3xl mx-auto px-4 md:px-0">
            <div className="flex items-center mb-10 mt-2 md:hidden fixed top-2 w-full max-w-[360px] mx-auto right-0 left-0 z-10 backdrop-blur-[2px] px-5">
                <BackButton icon action={() => navigate(-1)} />
                <p className="text-[#667085] font-medium text-xl w-full text-center mr-6">Buy Airtime</p>
            </div>
            
            <div className="hidden md:block">
                <BackButton className="mb-8" action={() => navigate(-1)} />
                <h1 className="font-medium text-2xl text-[var(--aqua)] mb-2">Recipient details</h1>
                <h2 className=" text-[#717171]">Enter your recipient details and amount</h2>
            </div>

            <form onSubmit={handleSubmit(onSubmit)} className="mt-14 md:mt-5 flex flex-col gap-8 pb-10">
                
                {/* Phone and Network section */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-6">
                    <div className="w-full order-1 md:order-1">
                        <label className="text-[#344054] text-sm font-medium mb-2 block" htmlFor="lastname">Phone number</label>
                        <Controller
                            name="phone"
                            control={control}
                            render={({ field }) => (
                                <PhoneInput
                                    country={'ng'}
                                    value={field.value}
                                    onChange={field.onChange}
                                    placeholder="phone number"
                                    onFocus={() => setIsFocused(true)}
                                    onBlur={() => {
                                        setIsFocused(false)
                                        field.onBlur()
                                    }}
                                    inputProps={{
                                        name: "phone",
                                    }}
                                    buttonStyle={{
                                        borderRadius: "8px 0 0 8px",
                                        border: isFocused ? "1px solid var(--brand-ink)" : "1px solid #D0D5DD",
                                        background: "#FFFFFF",
                                    }}
                                    inputStyle={{
                                        width: "100%",
                                        outline: "0",
                                        background: "#FFFFFF",
                                        height: "48px",
                                        border: isFocused ? "1px solid var(--brand-ink)" : "1px solid #D0D5DD",
                                        boxShadow: "0px 1px 3px rgba(16, 24, 40, 0.04)",
                                        borderRadius: "8px",
                                        color: "#344054",
                                        fontSize: "16px",
                                    }}
                                />

                            )}
                        />
                        {(!isVerifying && verifyErrData) && <p className="text-red-500 text-sm mt-1">Please input a valid {provider?.replace("-airtime", "")} number</p>}
                        {isVerifying && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { duration: .5 } }} className="flex items-center gap-2 mt-2"><Loader2 className="animate-spin size-4 text-[var(--brand-ink)]" /> <span className="italic text-sm text-slate-500">Verifying phone number</span></motion.div>}
                        {verifiedPhone?.isValid && (
                            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { duration: .5 } }} className="flex mt-2 items-center gap-2">
                                <div className="grid place-items-center size-5 rounded-full bg-[var(--money-in)] text-white"><BsCheck2Circle className="size-3" /> </div>
                                <p className="text-sm font-medium text-[var(--money-in)]">Verified</p>
                            </motion.div>
                        )}
                    </div>

                    <div className="w-full order-2 md:order-2">
                        <NetworkProviderPicker
                            providers={providers}
                            isLoading={isLoading}
                            selectedProviderCode={provider}
                            onSelect={(code) => update({ provider: code })}
                        />
                    </div>
                </div>

                {/* Amount section */}
                <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-6 items-end">
                    <div className="w-full">
                        <div className="flex items-center justify-between mb-2">
                            <label className="text-sm text-[#344054] font-medium" htmlFor="amount">Amount</label>
                            <p className="text-xs text-[#464E60] flex items-center gap-1">Available balance :
                                <span className="font-bold">
                                    {fetchingWallet ? <Loader2 className="animate-spin size-3" />
                                        : formatAmount(wallet?.balance as number)}
                                </span>
                            </p>
                        </div>
                        <div className="w-full h-fit relative">
                            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-xl">₦</span>
                            <input
                                {...register("amount")}
                                placeholder="0.00"
                                className="w-full border-[0.5px] border-[#D0D5DD] rounded-lg py-3 pl-10 pr-4 bg-white outline-none focus:border-[var(--brand-ink)] placeholder:text-sm placeholder:text-[#667085] font-mono text-xl font-semibold text-slate-700"
                                onInput={(e) => {
                                    const input = e.target as HTMLInputElement;
                                    input.value = input.value.replace(/[^0-9]/g, '');
                                }}
                                type="text"
                                min={50}
                                inputMode="numeric"
                                pattern="[0-9]*"
                                id="amount"
                            />
                        </div>
                        {errors.amount && <p className="text-red-500 text-sm mt-1">{errors.amount.message}</p>}

                        {cashbackRule && (
                            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="w-full mt-3 bg-[var(--money-in)]/10 border border-[var(--money-in)]/20 rounded-lg p-3 flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                    <div className="bg-[var(--money-in)]/20 rounded-full p-1"><BsCheck2Circle className="text-[var(--money-in)] size-4" /></div>
                                    <span className="text-sm font-medium text-[var(--money-in)]">
                                        Earn {cashbackRule?.type === 'percentage'
                                            ? `${cashbackRule?.value}%`
                                            : formatAmount(Number(cashbackRule?.value))} Cashback
                                    </span>
                                </div>
                            </motion.div>
                        )}
                    </div>

                    <CustomButton
                        disabled={!provider || !phoneNo}
                        className="w-full !bg-[var(--brand)] hover:!bg-[var(--brand-ink)] !text-white !h-12"
                    >
                        Proceed - <span className="opacity-80 ml-1">Confirm Purchase</span>
                    </CustomButton>
                </div>
            </form>
        </section>
    )
}

export default RecipientDetails