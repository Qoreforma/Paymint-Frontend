import { useEffect } from "react";
import RecipientDetails from "./RecipientDetails";
import useServiceFlowStore from "@/stores/useServiceFlowStore";
import ConfirmAirtimePayment from "./ConfirmAirtimePayment";
import Status from "./Status";
import { useQuery } from "@tanstack/react-query";
import { getServicesStatus, getCashbackRules, ServicesData } from "@/lib/api/dashboard-apis/generics";
import EmptyState from "../../EmptyState";
import Loader from "@/components/Loader";

const Airtime = () => {
  
  const AirtimePurchaseSteps = [
    { id: 1, component: RecipientDetails },
    { id: 2, component: ConfirmAirtimePayment },
    { id: 3, component: Status },
  ];
    
  const { data: servicesStatus, isLoading } = useQuery<ServicesData, Error>({
      queryKey: ["servicesStatus"],
      queryFn: getServicesStatus,
  });
  
  const { data: cashbackRules } = useQuery({
      queryKey: ["cashbackRules", servicesStatus?.airtime?._id],
      queryFn: () => getCashbackRules(servicesStatus?.airtime?._id as string),
      enabled: !!servicesStatus?.airtime?._id,
  });
  
  const {step, reset, update} = useServiceFlowStore();

  useEffect(() => {
      reset();
  }, [reset]);

  useEffect(() => {
      if (cashbackRules && cashbackRules.length > 0) {
          update({ cashbackRule: cashbackRules[0] });
      }
  }, [cashbackRules, update]);

  const CurrentComponent = AirtimePurchaseSteps[step - 1]?.component || AirtimePurchaseSteps[0].component;


    const statusMsg = servicesStatus?.airtime.status !== "active" ? servicesStatus?.airtime.message : null;

    if (isLoading) return <Loader className="w-full h-full" />;

    if (statusMsg) return <EmptyState showBackBtn={true} text={statusMsg} />;
  
  return (
    <div className="min-h-full flex md:items-center justify-center">
        <CurrentComponent />
    </div>
  )
}

export default Airtime;