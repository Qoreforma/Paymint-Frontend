import React from "react";
import { cn } from "@/lib/utils";
import { Check, Loader2 } from "lucide-react";
import { motion } from "framer-motion";

export type Provider = {
    id: string;
    name: string;
    code: string;
    logo: string;
};

interface NetworkProviderPickerProps {
    providers?: Provider[];
    isLoading: boolean;
    selectedProviderCode: string | null;
    onSelect: (providerCode: string, providerId: string) => void;
    label?: string;
}

const getNetworkColor = (code: string) => {
    const lowerCode = code.toLowerCase();
    if (lowerCode.includes("mtn")) return "var(--network-mtn)";
    if (lowerCode.includes("airtel")) return "var(--network-airtel)";
    if (lowerCode.includes("glo")) return "var(--network-glo)";
    if (lowerCode.includes("9mobile") || lowerCode.includes("etisalat")) return "var(--network-9mobile)";
    return "var(--brand-ink)"; // fallback
};

const NetworkProviderPicker: React.FC<NetworkProviderPickerProps> = ({
    providers,
    isLoading,
    selectedProviderCode,
    onSelect,
    label = "Network provider"
}) => {
    return (
        <div className="w-full">
            <label className="text-sm text-[#344054] font-medium block mb-2">{label}</label>
            
            {isLoading ? (
                <div className="flex items-center gap-2 text-sm text-gray-500 py-3">
                    <Loader2 className="animate-spin size-4" /> Loading providers...
                </div>
            ) : (
                <div className="grid grid-cols-4 gap-3">
                    {providers?.map((prov, i) => {
                        const isSelected = selectedProviderCode === prov.code;
                        const networkColor = getNetworkColor(prov.code);
                        
                        return (
                            <motion.button
                                key={prov.id}
                                type="button"
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: i * 0.05 }}
                                onClick={() => onSelect(isSelected ? "" : prov.code, isSelected ? "" : prov.id)}
                                className={cn(
                                    "relative overflow-hidden flex flex-col items-center justify-center p-3 rounded-xl border transition-all h-[90px] md:h-24",
                                    isSelected ? "shadow-md ring-1" : "border-slate-200 bg-white hover:border-[var(--brand-ink)]/30 hover:shadow-sm"
                                )}
                                style={{
                                    borderColor: isSelected ? networkColor : undefined,
                                }}
                            >
                                <div 
                                    className="absolute top-0 left-0 right-0 h-1.5 opacity-80"
                                    style={{ backgroundColor: networkColor }}
                                />
                                {isSelected && (
                                    <div className="absolute top-1.5 right-1.5 bg-white rounded-full">
                                        <Check className="size-3.5" style={{ color: networkColor }} strokeWidth={3} />
                                    </div>
                                )}
                                <div className="bg-slate-50 p-1.5 rounded-full mt-2 mb-1.5">
                                    <img src={prov.logo} className="size-6 object-cover rounded-full" alt={prov.name} />
                                </div>
                                <span className="text-[10px] md:text-xs font-semibold text-slate-700 text-center uppercase tracking-wider truncate w-full px-1">
                                    {prov.name.replace("Data", "").trim()}
                                </span>
                            </motion.button>
                        );
                    })}
                    {(!providers || providers.length === 0) && !isLoading && (
                        <p className="col-span-4 text-sm text-gray-500 py-2">No providers found.</p>
                    )}
                </div>
            )}
        </div>
    );
};

export default NetworkProviderPicker;
