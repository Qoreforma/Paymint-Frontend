import { Link } from "react-router-dom"
import { motion } from "framer-motion"
import { useEffect } from "react"
import { useQueryClient } from "@tanstack/react-query"
import { fetchAirtimeProviders, fetchDataProviders, fetchElectricityProviders, fetchBettingProviders } from "@/lib/api/dashboard-apis/servicesApis"
import { Smartphone, Globe, Zap, Tv } from "lucide-react"

const topServices = [
  {
    id: 1,
    label: "Airtime",
    subtitle: "Top up any network",
    icon: Smartphone,
    href: "/dashboard/services/airtime",
    iconColor: "text-blue-600",
    bgColor: "bg-blue-50/50",
    borderColor: "border-blue-100",
  },
  {
    id: 2,
    label: "Data",
    subtitle: "Cheap data bundles",
    icon: Globe,
    href: "/dashboard/services/data",
    iconColor: "text-green-600",
    bgColor: "bg-green-50/50",
    borderColor: "border-green-100",
  },
  {
    id: 3,
    label: "Electricity",
    subtitle: "Pay electricity bills",
    icon: Zap,
    href: "/dashboard/services/electricity",
    iconColor: "text-amber-500",
    bgColor: "bg-amber-50/50",
    borderColor: "border-amber-100",
  },
  {
    id: 4,
    label: "Cable TV",
    subtitle: "Pay for cable subscriptions",
    icon: Tv,
    href: "/dashboard/services/cable",
    iconColor: "text-indigo-600",
    bgColor: "bg-indigo-50/50",
    borderColor: "border-indigo-100",
  }
];

const ServicesList = () => {
  const queryClient = useQueryClient();

  useEffect(() => {
    // Silently pre-fetch most commonly used providers for instant loading
    queryClient.prefetchQuery({ queryKey: ["airtime-providers"], queryFn: fetchAirtimeProviders });
    queryClient.prefetchQuery({ queryKey: ["data-providers"], queryFn: fetchDataProviders });
    queryClient.prefetchQuery({ queryKey: ["electricity-providers"], queryFn: fetchElectricityProviders });
    queryClient.prefetchQuery({ queryKey: ["betting-providers"], queryFn: fetchBettingProviders });
  }, [queryClient]);

  return (
    <section className="mt-8 bg-transparent rounded-xl">
        <div className="flex justify-between items-center px-2 md:px-0">
          <h2 className="text-slate-800 font-display text-base md:text-lg font-semibold">Services</h2>
          <Link to="/dashboard/services" className="text-blue-600 text-sm font-medium hover:underline">
            See all
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4 py-2 px-2 md:px-0">
          {
              topServices.map(({id, label, subtitle, icon: Icon, href, iconColor, bgColor, borderColor}, i) => (
                  <motion.div 
                    initial={{opacity: 0, y: 15}}
                    whileInView={{opacity: 100, y: 0}}
                    whileHover={{y: -4, scale: 1.02}}
                    transition={{delay: i*0.05, duration: .3 }}
                    viewport={{once: true}}
                    key={id} 
                    className="flex flex-col group cursor-pointer w-full"
                  >
                      <Link 
                        to={href} 
                        className={`relative overflow-hidden flex flex-col items-center justify-center p-5 border ${borderColor} ${bgColor} rounded-2xl transition-all duration-300 hover:shadow-md h-[160px]`}
                      >
                          <div className={`w-14 h-14 rounded-full bg-white flex items-center justify-center shadow-sm mb-4 border ${borderColor}`}>
                             <Icon className={`size-6 ${iconColor}`} strokeWidth={1.5} />
                          </div>
                          <p className="text-slate-800 font-display text-sm font-semibold tracking-tight text-center">{label}</p>
                          <p className="text-slate-500 text-[11px] text-center leading-tight mt-1 px-1">
                            {subtitle}
                          </p>
                      </Link>
                  </motion.div>
              ))
            }
        </div>
    </section>
  )
}

export default ServicesList