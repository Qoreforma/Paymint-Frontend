import { getWallet } from "@/lib/api/dashboard-apis/walletApis";
import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { useState } from "react";
import { ImEyeBlocked, ImEye } from "react-icons/im";

interface TransactionMeta {
  paid_on: string;
  event_type: string;
  customer_email: string;
  payment_method: string;
  wallet_balance: number;
  settlement_amount: number;
}

interface Transaction {
  id: string;
  reference: string;
  provider_reference: string;
  amount: number;
  type: "credit" | "debit";
  provider: string;
  remark: string;
  purpose: string;
  status: "successful" | "pending" | "failed";
  meta: TransactionMeta;
  created_at: string;
}

export interface Wallet {
  type: string;
  balance: number;
  transactions: Transaction[];
}

const BalanceCard = () => {
    const [hideBalance, setHideBalance] = useState(false);

    const {
        data: wallet,
        isLoading,
    } = useQuery<Wallet, Error>({
        queryKey: ["wallet-balance"],
        queryFn: getWallet,
    })

    const rawFormatted = wallet && typeof wallet.balance === "number" ? wallet.balance.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "0.00";
    const [integerPart, decimalPart] = rawFormatted.split('.');

  return (
    <div className="relative w-full bg-gradient-to-br from-[#1241C9] to-[#0A2980] overflow-hidden h-[180px] px-6 md:px-8 py-6 rounded-2xl flex flex-col shadow-sm">
        
        {/* Aesthetic background gradients/shapes */}
        <div className="absolute top-0 right-0 -mr-12 -mt-12 w-64 h-64 rounded-full bg-white/5 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-16 -mb-16 w-40 h-40 rounded-full bg-white/5 blur-2xl pointer-events-none" />

        {/* 3D Wallet Graphic */}
        <div className="absolute right-[-10px] bottom-[-20px] h-[130%] w-[50%] max-w-[200px] flex items-end justify-end pointer-events-none">
            <img 
              src="/src/assets/dashboard/wallet-3d.png" 
              alt="" 
              className="w-full h-full object-contain object-bottom mix-blend-screen opacity-90 drop-shadow-2xl"
            />
        </div>

        <div className="relative z-10 w-full flex flex-col mt-1">
            <div className="flex items-center gap-2 mb-2">
                <p className="text-sm text-blue-100 font-medium tracking-wide">Available Balance</p>
                <button className="text-blue-200 hover:text-white transition-colors cursor-pointer" onClick={() => setHideBalance(prev => !prev)}>
                    {hideBalance ? <ImEyeBlocked className="size-4" /> : <ImEye className="size-4" />}
                </button>
            </div>
            
            {hideBalance ? (
                <span className="text-white font-bold text-4xl tracking-widest block mt-1">••••••</span>
            ) : isLoading ? (
                <Loader2 className="text-blue-300 animate-spin mt-2 size-8" />
            ) : (
                <h2 className="text-white font-bold text-4xl md:text-5xl tracking-tight mt-1 tabular-nums leading-none">
                    ₦{integerPart}<span className="text-blue-200 text-2xl md:text-3xl">.{decimalPart}</span>
                </h2>
            )}

            <button 
                onClick={() => setHideBalance(prev => !prev)}
                className="mt-6 flex items-center gap-2 bg-white/10 hover:bg-white/20 transition-all border border-white/20 rounded-full px-4 py-1.5 w-fit backdrop-blur-sm cursor-pointer"
            >
                {hideBalance ? <ImEye className="size-3.5 text-white" /> : <ImEyeBlocked className="size-3.5 text-white" />}
                <span className="text-xs text-white font-medium">{hideBalance ? "Show Balance" : "Hide Balance"}</span>
            </button>
        </div>
    </div>
  )
}

export default BalanceCard