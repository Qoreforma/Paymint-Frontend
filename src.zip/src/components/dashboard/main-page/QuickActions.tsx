import { quickActions } from "@/lib/constants"
import { Link } from "react-router-dom"
import {motion} from "framer-motion"

const QuickActions = () => {
  return (
    <section className="bg-white rounded-2xl border border-slate-200 shadow-sm py-6 px-4 md:px-8 mt-5 z-10">
         <div className="flex items-center justify-between w-full">
            {
                quickActions.map(({id, href, label, icon: Icon}, i) => (
                  <motion.div
                    initial={{opacity: 0, y: 10}}
                    whileInView={{opacity: 100, y: 0}}
                    transition={{delay: i*0.05, duration: .5 }}
                    viewport={{once: true}}
                    key={id}
                    className="flex-1"
                  >
                    <Link to={href} className="flex flex-col items-center gap-3 group">
                        {/* Circular icon container with outline */}
                        <div className="size-12 md:size-[52px] bg-blue-50 text-blue-600 border-2 border-blue-100 rounded-full flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white group-hover:border-transparent transition-all duration-300">
                          <Icon className="size-5 md:size-6" strokeWidth={1.5} />
                        </div>
                        <p className="text-slate-700 font-display text-[11px] md:text-sm font-medium text-center leading-tight max-w-[80px]">
                          {label}
                        </p>
                    </Link>
                  </motion.div>
                ))
            }
         </div>
    </section>
  )
}

export default QuickActions