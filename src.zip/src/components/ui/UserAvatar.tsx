import React from "react";
import { User } from "@/context/AuthContext";
import { cn } from "@/lib/utils";

interface UserAvatarProps {
    user: User | null | undefined;
    className?: string;
}

const UserAvatar: React.FC<UserAvatarProps> = ({ user, className }) => {
    if (!user) {
        return (
            <div className={cn("size-full rounded-full bg-slate-200 animate-pulse", className)} />
        );
    }

    if (user.avatar) {
        return (
            <img 
                src={user.avatar} 
                alt={`${user.firstname} ${user.lastname}`} 
                className={cn("size-full rounded-full object-cover", className)} 
            />
        );
    }

    const getInitials = () => {
        const first = user.firstname ? user.firstname[0] : "";
        const last = user.lastname ? user.lastname[0] : "";
        return (first + last).toUpperCase() || "?";
    };

    return (
        <div 
            className={cn(
                "size-full rounded-full bg-[var(--brand-ink)]/10 text-[var(--brand-ink)] flex items-center justify-center font-bold text-sm select-none border border-[var(--brand-ink)]/20", 
                className
            )}
            title={`${user.firstname} ${user.lastname}`}
        >
            {getInitials()}
        </div>
    );
};

export default UserAvatar;
